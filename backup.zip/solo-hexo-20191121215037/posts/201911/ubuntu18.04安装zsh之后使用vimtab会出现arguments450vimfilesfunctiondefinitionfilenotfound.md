title: 'ubuntu 18.04 安装zsh之后，使用vim+tab会出现  _arguments:450: _vim_files: function definition
  file not found'
date: '2019-11-13 11:48:32'
updated: '2019-11-13 11:51:00'
tags: [ubuntu]
permalink: /articles/2019/11/13/1573616912601.html
---
安装zsh之后，使用vim出现错误：

	 _arguments:450: _vim_files: function definition file not found

解决方法：

	执行命令：rm ~/.zcompdump
