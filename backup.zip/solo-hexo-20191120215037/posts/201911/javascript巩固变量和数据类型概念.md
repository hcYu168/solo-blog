title: javascript 巩固变量和数据类型概念
date: '2019-11-19 14:06:25'
updated: '2019-11-19 23:56:24'
tags: [javascript]
permalink: /articles/2019/11/19/1574143585724.html
---
## 1、变量：
- ECMAScript的变量是松散类型，所谓松散类型就是可以用来保存任何类型的数据。换句话说，每个变量仅仅使用一个保存值的占位符。
- 修改变量值的同时修改值的类型
`` let message = 'hi'; ``
``  message = 100;  //有效但不推荐``
- 局部变量，这个变量在函数退出后就会被销毁。
- 在严格模式下，不能定义名为eval 或 arguments的变量怕，否则会导致语法错误

## 2、数据类型：
- 基本数据类型：undefined、null、boolean、number、string
- 复杂数据类型：object, 本质上是由一族无序的名值对组成

2.1. typeof 操作符：检测给定变量的数据类型
- object ——如果这个值是对象或null; //这个比较特殊，需注意

2.2 undefined类型
- undefined类型只有一个值，即特殊的undefined. 使用var 声明变量但未对其加以初始化时，这个变量的值就是undefined.
- 注意：对未初始化的变量执行typeof操作符会返回undefined值，而对未声明的变量执行typeof操作也会返回undefined值。
`` eg: var message; ``
`` // var age;``
`` alert(typeof message); // "undefined" ``
`` alert（typeof age); // "undefined" ``
`` 所以，需要声明变量时，最好就初始化变量，这样我们检测变量时，就知道是还没有被声明，而不是没有初始化；``

2.3 null类型
- null值表示一个空对象指针，而这也是typeof 检测null值会返回"object"的原因
- 注意：只要意在保存对象的变量还没有真正保存对象，就应该明确地让该变量保存null值，这样不仅可以体现null作为空对象指针的惯例，也有助于进一步区分null和undefined。

2.4 number类型
- 关于浮点数值计算会产生舍入误差的问题，这是使用基于IEEE754数值的浮点计算的通病。
`` eg: 0.1+0.2 结果不等于0.3，而是等于0.30000000000000004 ``
- NaN,即非数值是一个特殊的数值，表示一个本来要返回数组的操作数未返回数值的情况。
- 数值转换，有三个函数可以把非数值转化为数值：Number()、parseInt()、parseFloat()。

2.4.1 Number()函数的转换规则：

-  如果是Boolean，true和false将分别被转换为1和0；
- 如果是数字值，只是简单的传入和返回；
- 如果是null值，则返回0;
- 如果是undefined, 则返回NaN;
- 如果是字符串只包含数字，则将其转换为10进制数值，即"1"会变成1，而"011"则变成11；
- 如果字符串包含有限的浮点格式，则转换为对应的浮点数值。（也会忽略前导0）
- 如果字符串中包含有效的十六进制格式，则会转换为相同大小的十进制整数值；
- 如果是空字符串，则转换为0；
- 如果字符串包含除上述格式之外的符号，则转为NaN;
- 如果是对象，则调用对象的valueOf()方法，然后依照签名的规则转换返回的值。如果转换的结果是NaN,则调用对象的toString()方法，再依次依照签名的规则转换返回的字符串值。
`` eg: const num1 = Number('hello world');  // NaN ``
`` const num2 = Number("");   // 0 ``
`` const num3 = Number("000111")   // 111 ``
`` const num4 = Number(true);     // 1``

2.4.2 parseInt()函数转换：
- parseInt()能够识别出各种整数格式（十进制， 八进制，十六进制）, 所以为了避免错误的解析，建议无论什么情况下都明确指定基数。
`` eg: const num1 = parseInt("10", 2);    // 2（按二进制解析) ``
`` const num2 = parseInt("10", 8);         //  8  (按八进制解析）``
`` const num3 = parseInt("10", 10)       // 10  ( 按十进制解析）``
`` const num4 = parseInt("10", 16)       // 16  ( 按十六进制解析）``

2.4.3 parseFloat()函数转换:
- 与parseInt()函数类似，区别在于parseFloat始终会忽略前导0。
- 解析字符串第一个小数点是有效的，第二个小数点就无限，会被忽略。
- 如果字符串包含的是一个可解析为整数的值，parseFloat()会返回整数。

2.5 String类型
- 默认情况下，toString()方法以十进制格式返回数值的字符串表示，toString()也可以输出以二进制，八进制，十六进制，乃至其他有效进制格式表示的字符串值。
- 还有一种转型函数String(),用来区分转换的值是null还是undefined。
`` eg:  const value1 = null; ``
 ``alert(String(value1))  // null ``
`` let value2; ``
 ``alert(String(value2))  // undefined ``

2.6 Object 类型：Object的每个实例都具有下列属性和方法
- constructor: 保存着用于创建当前对象的函数。Object() 即是一个构造函数。
- hasOwnProperty(propertyName): 用于检查给定的属性在当前对象实例中是否存在。其中，作为参数的属性名（propertyName)必须以字符串形式指定。
- isPrototypeOf(object): 用于检查传入的对象是否是当前对象的原型。
- propertyIsEnumerable(propertyName): 用于检查给定的属性是否能够使用for-in语句来枚举。
- toLocaleString(): 返回对象的字符串表示，该字符串与执行环境的地区对应。
- toString()：返回对象的字符串表示。
- valueOf(): 返回对象的字符串、数值或布尔值表示。通常与toString()方法返回值一样。
