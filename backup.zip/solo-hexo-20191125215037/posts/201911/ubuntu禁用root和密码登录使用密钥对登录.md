title: ubuntu 禁用root和密码登录，使用密钥对登录
date: '2019-11-18 16:30:11'
updated: '2019-11-18 16:30:11'
tags: [ubuntu]
permalink: /articles/2019/11/18/1574065811831.html
---
流程：

1、ssh 登录服务器 

2、添加用户和用户密码
- **1、adduser 用户名**
- **2、pwduser 用户名，回车，输入密码**

3、新用户增加sudo权限：
- **1、sudo visudo**
- **2、复制root行**
- **3、将root改为新用户名**
- **4、保存：Ctrl+O + 回车**
- **5、退出：Ctrl+X**

5、登录新用户：
 - **1、su 用户名**
 - **2、mkdir ~/.ssh && vi ~/.ssh/authorized_keys**
 - **3、添加本地rsa公钥（操作电脑的rsa公钥）到文件中，保存退出**
 - **4、 authorized_keys里面每一行代表一个用户公钥**
 - **5、退出： exit**

 
6、禁用root用户登录&密码登录

- 1、 打开配置文件
**vi /etc/ssh/sshd_config**

- 2、 禁用root用户登录
**PermitRootLogin yes -> PermitRootLogin no**

- 3、 禁用密码登录
**PasswordAuthentication yes -> PasswordAuthentication no**

- 4、开启密钥对登录
**PubkeyAuthentication no -> PubkeyAuthentication yes**

- 5、重启sshd
**service sshd restart**

 

6、退出root登录，使用新用户登录


`` ssh 新用户名@xxx.xxx.xxx.xxx -p 22``
